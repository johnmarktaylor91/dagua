#!/usr/bin/env bash
# setup-architect-worker.sh
# Install the Architect-Worker development system.
#
# Usage:
#   ./setup-architect-worker.sh --global     # Install ~/.claude/ and ~/.codex/
#   ./setup-architect-worker.sh --project    # Install project templates
#   ./setup-architect-worker.sh --both       # Install everything
#   ./setup-architect-worker.sh --portability # Show new-machine setup instructions

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

install_global() {
  echo "=== Installing global configs ==="
  for dir in ~/.claude ~/.claude/knowledge ~/.codex; do mkdir -p "$dir"; done

  # Claude Code global
  for f in CLAUDE.md settings.json; do
    if [ -f "$HOME/.claude/$f" ]; then
      cp "$HOME/.claude/$f" "$HOME/.claude/$f.bak"
      echo "  Backed up ~/.claude/$f"
    fi
  done
  cp "$SCRIPT_DIR/global-claude/CLAUDE.md" ~/.claude/CLAUDE.md
  cp "$SCRIPT_DIR/global-claude/settings.json" ~/.claude/settings.json
  echo "  ✓ ~/.claude/CLAUDE.md + settings.json"

  # Knowledge seeds (don't overwrite if they exist and have content)
  for f in lessons.md patterns.md; do
    if [ ! -f "$HOME/.claude/knowledge/$f" ] || [ ! -s "$HOME/.claude/knowledge/$f" ]; then
      cp "$SCRIPT_DIR/global-claude/knowledge/$f" "$HOME/.claude/knowledge/$f"
      echo "  ✓ ~/.claude/knowledge/$f"
    else
      echo "  ~/.claude/knowledge/$f exists with content — keeping"
    fi
  done

  # Codex global
  for f in AGENTS.md config.toml; do
    if [ -f "$HOME/.codex/$f" ]; then
      cp "$HOME/.codex/$f" "$HOME/.codex/$f.bak"
      echo "  Backed up ~/.codex/$f"
    fi
  done
  cp "$SCRIPT_DIR/global-codex/AGENTS.md" ~/.codex/AGENTS.md
  cp "$SCRIPT_DIR/global-codex/config.toml" ~/.codex/config.toml
  echo "  ✓ ~/.codex/AGENTS.md + config.toml"

  echo ""
  echo "Set ntfy env vars in your shell profile:"
  echo '  export NTFY_TOPIC="dev-notify"'
  echo '  export NTFY_SERVER="http://mac-mini.local:8080"  # or https://ntfy.sh'
}

install_project() {
  echo "=== Installing project templates ==="
  mkdir -p .project-context/{tasks,knowledge,research} scripts .claude/commands

  for f in CLAUDE.md AGENTS.md; do
    if [ -f "$f" ]; then
      echo "  $f exists — skipping"
    else
      cp "$SCRIPT_DIR/project-template/$f" "./$f"
      echo "  ✓ $f"
    fi
  done

  for f in architecture.md conventions.md; do
    if [ -f ".project-context/$f" ]; then
      echo "  .project-context/$f exists — skipping"
    else
      cp "$SCRIPT_DIR/project-template/.project-context/$f" ".project-context/$f"
      echo "  ✓ .project-context/$f"
    fi
  done

  for f in gotchas.md decisions.md; do
    if [ ! -f ".project-context/knowledge/$f" ]; then
      cp "$SCRIPT_DIR/project-template/.project-context/knowledge/$f" ".project-context/knowledge/$f"
      echo "  ✓ .project-context/knowledge/$f"
    fi
  done

  if [ ! -f ".project-context/todos.md" ]; then
    cp "$SCRIPT_DIR/project-template/.project-context/todos.md" ".project-context/todos.md"
    echo "  ✓ .project-context/todos.md"
  fi

  cp "$SCRIPT_DIR/project-template/scripts/"*.sh ./scripts/
  chmod +x scripts/*.sh
  echo "  ✓ scripts/"

  for f in review-codebase.md iterate-until-green.md goodnight.md; do
    cp "$SCRIPT_DIR/project-template/.claude/commands/$f" ".claude/commands/$f"
  done
  echo "  ✓ .claude/commands/"

  if [ ! -f .claude/settings.json ]; then
    cp "$SCRIPT_DIR/project-template/.claude/settings.json" .claude/settings.json
    echo "  ✓ .claude/settings.json"
  fi

  if ! grep -q ".project-context/tasks/" .gitignore 2>/dev/null; then
    echo "" >> .gitignore
    cat "$SCRIPT_DIR/project-template/gitignore-additions.txt" >> .gitignore
    echo "  ✓ .gitignore updated"
  fi

  # Set up personal git exclude
  mkdir -p .git/info 2>/dev/null || true
  if [ -d .git/info ] && [ ! -s .git/info/exclude ]; then
    cp "$SCRIPT_DIR/project-template/git-exclude-template.txt" .git/info/exclude
    echo "  ✓ .git/info/exclude"
  fi

  echo ""
  echo "Next: Fill in <!-- --> placeholders in CLAUDE.md and AGENTS.md"
}

show_portability() {
  cat <<'PORTABILITY'
=== Setting Up on a New Machine ===

1. Install tools:
   npm install -g @anthropic-ai/claude-code @openai/codex
   brew install gh ruff mypy  # or pip install ruff mypy

2. Copy global configs from old machine:
   scp -r old-machine:~/.claude/ ~/.claude/
   scp -r old-machine:~/.codex/ ~/.codex/

   This includes:
   - ~/.claude/CLAUDE.md (architect identity)
   - ~/.claude/settings.json (permissions, hooks)
   - ~/.claude/knowledge/ (lessons, patterns — your accumulated wisdom)
   - ~/.codex/AGENTS.md (worker rules)
   - ~/.codex/config.toml (model config)

3. Set environment variables (add to ~/.zshrc or ~/.bashrc):
   export NTFY_TOPIC="dev-notify"
   export NTFY_SERVER="http://your-ntfy-server:8080"

4. Authenticate:
   claude   # follow auth prompts
   codex    # follow auth prompts
   gh auth login

5. Each project already has its configs in the repo:
   git clone <project> && cd <project>
   claude --dangerously-skip-permissions

That's it. All project-level configs (CLAUDE.md, AGENTS.md, scripts,
.project-context/) travel with the repo. Global configs travel with
your home directory.
PORTABILITY
}

case "${1:---both}" in
  --global)      install_global ;;
  --project)     install_project ;;
  --both)        install_global; echo ""; install_project ;;
  --portability) show_portability ;;
  *)
    echo "Usage: $0 [--global|--project|--both|--portability]"
    exit 1 ;;
esac
