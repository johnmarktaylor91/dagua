---
name: test-status
description: Check on running background pytest tasks and report results
---

# Test Status

Check on running background pytest tasks and report results in real time.

## Instructions

1. Use `TaskOutput` with `block: false` and `timeout: 5000` on the most recent background test task to get current output without waiting for completion.
   - If you don't have the task ID in context, list recent output files: `ls -lt /tmp/claude-*/tasks/*.output 2>/dev/null | head -5` and read the most recent one.

2. Parse the pytest output and present a **concise status table**:

   ```
   Test Run Status: [RUNNING | COMPLETE]
   Progress: X/N tests done

   PASSED:
   - test_name_1 (Xs)
   - test_name_2 (Xs)

   FAILED:
   - test_name_3 - <one-line error summary>

   SKIPPED:
   - test_name_4 - <reason>

   CURRENTLY RUNNING:
   - test_name_5 (started after last completed test)
   ```

3. Rules:
   - Keep it concise: one line per test, no full tracebacks
   - For failures, extract just the exception type and message (one line)
   - Show timing per test if available in the output
   - If the run is complete, show the final pytest summary line
   - If no background test task is found, say so
