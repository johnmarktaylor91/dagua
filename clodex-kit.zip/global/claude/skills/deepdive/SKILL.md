---
name: deepdive
description: >
  Deep multi-pass codebase inspection to build thorough understanding. Use when
  the user wants you to deeply learn a codebase through iterative passes —
  understanding architecture, design patterns, and building persistent notes
  that carry across sessions.
argument-hint: "[path] [min-passes] [persistence-rounds]"
---

# Deep Dive Codebase Inspection

You are performing an exhaustive, multi-pass inspection of a codebase. The
primary goal is to build YOUR deep understanding of the codebase — its
architecture, design philosophy, patterns, data flow, and conventions — so you
can work effectively in it across sessions. Cataloging bugs and issues is a
valuable secondary output.

## Setup

1. **Codebase path**: `$1` (if not provided, ask the user)
2. **Minimum passes**: `$2` (if not provided, default to 5)
3. **Persistence rounds**: `$3` (if not provided, default to 3) — the number
   of passes a question can remain open before being marked `ROADBLOCKED`. A
   question that stays unanswered (neither `ANSWERED` nor `PARTIALLY ANSWERED`)
   for this many consecutive passes is considered roadblocked. This applies to
   both self-generated and adversarial questions.
4. **Before starting**, confirm with the user:
   - The codebase path/scope to inspect
   - The minimum number of passes (suggest the default if not specified)
   - The persistence rounds (suggest the default of 3 if not specified)
   - Whether there are specific areas of focus or concern

## Notes Directory

Store ALL notes in the **project memory directory** — never in the project
itself (to avoid appearing in git). This is typically at:
`~/.claude/projects/<project-path-slug>/memory/`

Check if a memory directory already exists for this project. If it does, read
existing notes first to build on prior knowledge. If not, create one.

### Returning to a Previously Inspected Codebase

If prior deepdive session notes exist, run a delta check before starting:

1. Find the timestamp of the most recent prior session directory (from the
   folder name in `deepdive_sessions/`)
2. Run `git log --oneline --since="<timestamp>" -- <codebase-path>` to see
   what changed since the last session
3. Run `git diff --stat <latest-commit-from-last-session>..HEAD` using the
   HEAD hash recorded in the prior session's `process_summary.md`
4. Save the list of changed files and a brief summary of the changes to the
   new session's `inspection_log.md` under a `## Delta Since Last Session`
   heading
5. During Pass 1, **prioritize reading changed files first** — these are
   where your existing understanding is most likely to be stale. Then read
   other files as normal.
6. Check whether any changes invalidate prior notes in `architecture.md`
   or topic files. Update them if so.

At the end of each session, **explicitly record the current HEAD commit hash**
in `process_summary.md` so future sessions can compute an accurate diff.

At the start of each session, create a timestamped session directory:
`<memory-dir>/deepdive_sessions/YYYY-MM-DD_HH-MM-SS/`
(Use `date '+%Y-%m-%d_%H-%M-%S'` for the timestamp.) All session-specific logs
go here (see Session Log Directory below). Persistent knowledge files live at
the top level of the memory directory.

## Memory Structure

Create and maintain these files. Structure them so that a **fresh Claude session
can read them and immediately be productive** — they are your persistent brain.

### Core Understanding Files
- `MEMORY.md` — Top-level index linking to all topic files. Keep concise (under
  200 lines) since this is always loaded into context. Include key resolved
  questions, conventions, and documentation maintenance instructions.
- `architecture.md` — High-level architecture, file map with line counts and
  purposes, data flow diagrams, key abstractions, design philosophy, the
  "why" behind major decisions, AND recurring patterns/conventions/internal
  APIs. (Design patterns belong here rather than in a separate file — in
  practice, patterns and architecture are deeply intertwined and separating
  them causes constant cross-referencing.)

### Session Log Directory

Each deep dive session gets its own timestamped folder so that prior sessions
are preserved as a historical record. At the start of a session, create:

`deepdive_sessions/YYYY-MM-DD_HH-MM-SS/`

(Use the actual start time via `date '+%Y-%m-%d_%H-%M-%S'`.)

Place all session-specific artifacts inside this folder:

- `inspection_log.md` — Per-pass question log. For each pass: questions raised,
  questions answered from prior passes, new findings. Use IDs like `P1-Q1`,
  `P2-Q3` for cross-referencing. **Keep entries compact** — use the format
  `"P15: read postprocess.py, answered P14-Q1 (ANSWERED: buffer merge uses
  label strings), found bug #28"` rather than full prose. This is critical for
  context management (see below).
- `adversarial_log.md` — Adversarial agent questions and your answers, per round.
  Track question IDs like `R1-Q1`, `R2-Q3`. Record whether each answer was
  accepted, rejected, or prompted a followup. **Keep prior rounds compact** —
  retain full Q&A only for the current round and open questions. For resolved
  rounds, keep only a summary table (ID, verdict, 1-line summary).
- `process_summary.md` — End-to-end summary of the deep dive process. For each
  pass: wall-clock duration, new questions raised, questions answered, adversarial
  questions received and their outcomes. Written as you go — do not wait until
  the end. **Record the git HEAD commit hash at the end of the session.**

### Persistent Files (top-level in the memory directory, not per-session)

These files are cumulative across sessions and should be updated — not
recreated — with each deep dive:

- `todo.md` — Running to-do list: confirmed bugs (by severity), dead code,
  design issues, refactoring candidates, items needing user input.

### Comprehension Map

Maintain a `comprehension_map.md` file (persistent, top-level in the memory
directory) that tracks your confidence level for each major module or area of
the codebase. Use a simple three-tier scale:

- **deep** — You can trace code paths, explain design decisions, predict
  behavior in edge cases, and answer adversarial questions without re-reading.
- **moderate** — You understand the purpose and general flow but would need
  to re-read for specifics, edge cases, or non-obvious interactions.
- **surface** — You know the module exists and roughly what it does, but
  haven't traced through it in detail.

Format as a table:

```
| Module/Area       | Confidence | Last Updated | Notes                    |
|-------------------|------------|--------------|--------------------------|
| core/engine       | deep       | Pass 3       | Fully traced data flow   |
| api/routes        | moderate   | Pass 2       | Happy path clear, error  |
|                   |            |              | handling not yet traced   |
| utils/helpers     | surface    | Pass 1       | Skimmed, seems routine   |
```

Update this file at the end of every pass. This is lightweight — just a table,
~2 minutes per pass. Use it to:
- **Guide later passes**: Prioritize re-reading areas rated `surface` or
  `moderate` over areas already rated `deep`
- **Feed the adversarial agent**: Include the comprehension map in the
  adversarial prompt so it can target weak areas
- **Report to the user**: Include the final comprehension map in the
  post-completion findings summary

Link this file from `MEMORY.md`.

### Additional Topic Files (as needed)
Create topic-specific files for deep areas. Examples:
- `data_structures.md`, `testing.md`, `api.md`, `error_handling.md`

Link every topic file from `MEMORY.md`.

## Context Window Management

High pass counts WILL exhaust the context window. This was the #1 operational
problem in a 52-pass deep dive. Plan for it proactively:

### Keep Session Logs Compact
- **Inspection log**: Use compact one-line-per-event format (see above), not
  full prose. A 50-pass inspection log should fit in ~200 lines.
- **Adversarial log**: Keep full Q&A only for the CURRENT round and any OPEN
  (unresolved) questions. For resolved rounds, compress to a summary table:
  ```
  | Round | Questions | Accepted | Rejected | Followup | Notes |
  |-------|-----------|----------|----------|----------|-------|
  | R1    | 10        | 8        | 1        | 1        | FU resolved R2 |
  ```
- **Process summary**: This is inherently compact (one row per pass). No issue.

### Proactive Compaction
- After every 5-10 passes, review your session logs. If the adversarial log
  has grown large, compact resolved rounds into summary tables.
- If you notice context getting heavy (long tool results, large file reads),
  compact BEFORE being forced into a session restart.
- When compacting, preserve: open questions, current round details, summary
  statistics, and any insights not yet captured in persistent files.

### Persistent vs Session Knowledge
- Insights, bugs, and understanding belong in **persistent files**
  (architecture.md, todo.md, topic files). These survive session restarts.
- Session logs are process records. They're useful during the session but
  should not be the primary home for important discoveries.
- If a question forced you to discover something important, capture that
  discovery in the persistent knowledge base IMMEDIATELY — don't rely on
  being able to re-read the adversarial log later.

## Pass Structure

### Timing

Record the wall-clock start and end time of each pass using `date` via the Bash
tool. Log these in `process_summary.md` as you go — do not wait until the end.

### Pass 1: Initial Survey
1. **Record start time** for this pass
2. Read all source files systematically (use Explore agents in parallel for
   large codebases)
3. **Build understanding**: Map the architecture, identify key abstractions,
   trace data flow, understand design philosophy
4. Note every question, uncertainty, potential bug, or design concern
5. Write initial memory files — prioritize architecture and design understanding
6. **Write initial comprehension map**: Rate every major module/area you
   identified. Most will be `surface` or `moderate` after Pass 1 — that's
   expected.
7. Log all questions as `P1-Q1`, `P1-Q2`, etc. in `inspection_log.md`
8. **Record end time** and update `process_summary.md` with pass duration
9. **Launch adversarial agent** in background (see Adversarial Agent section)

### Pass N (N >= 2): Iterative Refinement

Each pass should touch every file in the codebase, but time allocation should
be proportional to remaining uncertainty. Well-understood utility files can be
scanned quickly to check for things you might have missed; complex algorithmic
files and areas rated `surface` or `moderate` in the comprehension map should
be re-read carefully. Do not reduce passes to "just answer open questions" —
the fresh read-through is the primary activity. But DO allocate your time
intelligently using the comprehension map.

For each pass:

1. **Record start time** for this pass
2. **Fresh read-through**: Go through the codebase again. Prioritize areas
   rated `surface` or `moderate` in the comprehension map. Look for
   connections, patterns, edge cases, and subtleties you missed in prior passes.
   This is the primary activity — not just answering questions.
3. **Answer prior questions**: While reading, address open questions from prior
   passes. For each:
   - Mark as `ANSWERED` with findings
   - Mark as `PARTIALLY ANSWERED` with what's known and what remains
   - Mark as `ROADBLOCKED` only if it has been open for the configured
     persistence rounds without resolution, OR if it clearly requires user
     input or is a design decision that cannot be resolved from the code alone
   - Track the **age** of each open question (how many passes since it was
     raised). Record this in `inspection_log.md` as e.g. `P1-Q3 [age: 2/3]`
     where the denominator is the persistence-rounds limit.
4. **Answer adversarial questions**: Address any open questions from the
   adversarial agent (see below)
5. **Find new questions**: Note new questions discovered during the fresh
   read-through as `PN-Q1`, etc.
6. **Deepen understanding**: Update architecture and design notes with new
   insights. Understanding how things work is as important as finding what's
   broken.
7. **Update to-do list**: Add confirmed bugs, dead code, design concerns
8. **Update comprehension map**: Re-rate modules based on this pass. Promote
   areas where understanding deepened. Note areas that remain shallow — these
   should be prioritized in the next pass.
9. **Log everything** in `inspection_log.md` under the current pass heading
   (compact format — see Context Window Management)
10. **Record end time** and update `process_summary.md` with pass duration,
    questions raised/answered, and adversarial outcomes for this pass
11. **Launch adversarial agent** in background for the next round

### What to Build Understanding Of
- Architecture: module boundaries, dependency graph, data flow
- Design philosophy: why things are built the way they are
- Key algorithms and their invariants
- Conventions and patterns used throughout
- Configuration and extension points
- Test strategy and coverage

### What to Catalog as Issues
- Bugs (logic errors, copy-paste errors, crash conditions)
- Dead code (unreachable functions, unused variables)
- Edge cases (unhandled inputs, missing error handling, race conditions)
- Design issues (inconsistent patterns, fragile assumptions)
- Code quality (naming inconsistencies, deprecated APIs)
- Test coverage gaps

## Adversarial Agent

Each round, launch an adversarial agent using the Task tool. This agent's job is
to stress-test your understanding by asking challenging questions that require
deep working knowledge of the code.

### Launching the Agent

Use the Task tool with `subagent_type: "general-purpose"` and
`run_in_background: true`. Launch it at the END of each pass so it can prepare
questions while you begin your next pass.

### Question Count Guidance

- **Rounds 1-5**: 5-10 questions per round. Cast a wide net.
- **Rounds 6-15**: 5-8 questions. Start focusing on deeper, harder questions.
- **Rounds 15+**: 3-5 questions. Prioritize quality over quantity. By this
  point the adversarial agent may struggle to find genuinely novel angles —
  fewer, harder questions are more valuable than padding with weaker ones.

### Adversarial Agent Prompt Template

Use this prompt (filling in the bracketed values):

```
You are an adversarial code reviewer stress-testing someone's understanding of
a codebase. Your job is to ask the HARDEST possible questions — ones that
require deep, working knowledge of the code to answer correctly.

CODEBASE: [path]
NOTES DIRECTORY: [memory path]
CURRENT ROUND: [round number, e.g. 1, 2, 3...]
COMPREHENSION MAP: [paste current contents of comprehension_map.md]

QUESTION COUNT: [see Question Count Guidance — fewer in later rounds]

INSTRUCTIONS:
1. Read the inspection notes in the notes directory to understand what has been
   learned so far. Pay close attention to what has already been answered well
   and where understanding still appears shallow.
2. Read the codebase source files directly.
3. Generate questions (see QUESTION COUNT). These should include:
   - "What if" scenarios: What happens if [unusual input/state]? Walk through
     the exact code path.
   - Edge cases: What happens when [boundary condition]? Which line handles it?
   - "Why is this here": Pick a non-obvious piece of code and ask why it exists.
     What breaks if you remove it?
   - Logic walkthroughs: Pick a complex function and ask for a step-by-step
     trace with specific inputs.
   - Cross-cutting concerns: How does [component A] interact with [component B]
     in [specific scenario]?
   - Failure modes: What happens when [operation] fails? Is it handled? Where?
4. Questions should be SPECIFIC — reference exact functions, files, and
   scenarios. Avoid vague questions.
5. Questions should target areas where the notes seem thin, uncertain, or where
   you suspect understanding may be shallow. Use the COMPREHENSION MAP to
   identify modules rated `surface` or `moderate` — these are prime targets.
6. Avoid asking about things already thoroughly answered in the notes.
7. Each question should have a clear, verifiable answer findable in the code.

ESCALATING DIFFICULTY:
As rounds progress, your questions should become progressively harder and more
sophisticated. Use the cumulative notes and prior Q&A history to identify where
to push deeper. In later rounds, favor questions that:
- Require synthesizing knowledge across multiple components or modules (e.g.,
  "If component A enters state X while component B is mid-operation Y, what
  happens at the boundary in [specific file/function]?")
- Probe non-obvious interactions, race conditions, or implicit coupling between
  subsystems
- Test understanding of subtle invariants — conditions the code silently
  depends on but never explicitly asserts
- Challenge whether the inspector understands WHY the code works, not just
  WHAT it does (e.g., "What would break if you reordered these two operations
  in [function]? Why are they ordered this way?")

Use your best judgment here. The goal is to test genuine limits of functional
understanding — how components interact under pressure, what edge cases are
truly dangerous, where the real complexity lives. Do NOT add complexity for its
own sake or ask convoluted multi-part questions that are hard to parse rather
than hard to answer. A great late-round question is simple to state but
requires deep knowledge to answer correctly.

PREVIOUS ADVERSARIAL QUESTIONS (do not repeat these):
[Summarize prior questions in 1-2 sentences each with their question IDs.
Do NOT paste full Q&A text — subagents have limited context. Example:
"R1-Q1: Traced exception path through torch_func_decorator (ACCEPTED)"
"R2-Q3: Asked about gradient hook lifecycle in two-pass mode (FOLLOWUP)"]

Format your output as a numbered list of questions, each with:
- The question
- Which file(s)/function(s) it targets
- Why this question is challenging (what understanding it tests)
- Difficulty rating: STANDARD, HARD, or EXPERT
```

### Evaluating Answers

After you attempt to answer the adversarial questions, launch another Task agent
to evaluate your answers:

```
You are evaluating answers to adversarial questions about a codebase. You must
be STRICT — only accept answers that demonstrate genuine understanding with
specific code references.

CODEBASE: [path]
QUESTIONS AND ANSWERS: [paste questions and your answers]

For each answer, determine:
1. ACCEPTED — Answer is correct, specific, and demonstrates real understanding.
   Cites relevant code locations.
2. REJECTED — Answer is wrong, vague, or missing key details. Explain what's
   wrong or missing.
3. FOLLOWUP — Answer is partially correct but raises a deeper question. State
   the followup question.

Be strict. Vague or hand-wavy answers should be REJECTED. Answers that are
correct but miss important nuance should get a FOLLOWUP.

Also: based on the answers, generate 1-3 NEW followup questions that probe
deeper into areas where understanding seems weakest.
```

### Evaluator Override

The evaluator agent is a tool, not an authority. If you believe an evaluator
verdict is incorrect (e.g., it rejected a correct answer due to misreading the
code, or accepted a subtly wrong answer), you may override it with a brief
justification in the adversarial log. Mark these as `OVERRIDDEN → ACCEPTED`
or `OVERRIDDEN → REJECTED` with your reasoning. Use this sparingly and
honestly — the evaluator is right more often than not.

### Adversarial Cycle

1. Adversarial agent generates questions (runs in background during your pass)
2. At the end of your pass, **check if the adversarial agent has finished**
   using `TaskOutput` with `block: false`. If it hasn't finished yet, wait
   for it with `TaskOutput` (block, timeout 120s).
3. Answer the adversarial questions
4. Launch the evaluator agent in background
5. You may begin reading code for the next pass while the evaluator runs, but
   you **must collect evaluator results before launching the next adversarial
   round**. This ensures adversarial questions build on evaluated answers.
6. REJECTED and FOLLOWUP items become open questions for the next pass
7. Log everything in `adversarial_log.md` (compact format for resolved rounds
   — see Context Window Management)
8. **Harvest insights**: After answering, review especially the HARD and EXPERT
   questions — regardless of whether the answer was ACCEPTED, REJECTED, or
   FOLLOWUP. The process of working through difficult questions often reveals
   subtle bugs, implicit invariants, non-obvious coupling, and edge cases that
   you would not have noticed during a normal read-through. Capture these
   insights in your persistent notes (architecture, todo, or a relevant topic
   file) so they are available to future sessions. Do not let hard-won
   understanding live only in the adversarial log — if a question forced you
   to discover something important about the code, that discovery belongs in
   the main knowledge base.

The adversarial agent is allowed to ask as many followup rounds as needed, but
must converge. If the same question has been asked and answered for the
configured persistence rounds without resolution, mark it as ROADBLOCKED.

## Termination Criteria

Stop iterating when ALL THREE conditions are met:

1. **Minimum passes completed**: At least N passes have been done
2. **Your questions exhausted**: All self-generated questions are either
   resolved (`ANSWERED`) or `ROADBLOCKED` (i.e., they have been open for the
   configured persistence rounds without resolution, or they require user input)
3. **Adversarial questions exhausted**: All adversarial questions are either
   ACCEPTED or ROADBLOCKED (no open REJECTED or FOLLOWUP items remain). A
   question is ROADBLOCKED only after it has persisted for the configured
   persistence rounds without acceptance.

If ANY of these conditions is not met, continue with another pass. Questions
that are still within their persistence window (i.e., age < persistence rounds)
are NOT considered roadblocked and keep the process going.

## Post-Completion

When termination criteria are met:

1. **Final update**: Ensure ALL memory files are current, comprehensive, and
   structured for future session pickup. A fresh Claude session reading these
   files should understand the codebase well enough to work in it immediately.
2. **Write process summary**: Finalize `process_summary.md` with the complete
   record of what happened. The summary should include:
   - Total passes completed and total wall-clock time
   - Per-pass breakdown: duration, new self-questions raised, prior questions
     answered, adversarial questions received, adversarial outcomes
     (accepted/rejected/followup/roadblocked)
   - Overall question flow: how many total questions were raised, answered,
     and roadblocked across all passes
   - Final termination reason (which criteria were met and when)
   - **Current git HEAD commit hash** (for future delta checks)
3. **Print process summary**: Output the full contents of `process_summary.md`
   to the user so they can see exactly what took place during the deep dive.
4. **Present findings summary to user**:
   - Key architectural insights and design understanding gained
   - **Final comprehension map**: Present the final state of
     `comprehension_map.md` so the user can see which areas are deeply
     understood and which remain at surface level
   - Confirmed bugs (by severity: critical, high, medium)
   - Dead code found
   - Design concerns and refactoring candidates
   - Roadblocked items that need user input
   - **Most challenging adversarial questions**: Highlight 3-5 of the hardest
     adversarial questions encountered across all rounds — the ones that were
     most difficult to answer, required the deepest understanding, or revealed
     the most interesting aspects of the codebase. For each, briefly summarize
     the question, what made it hard, and the outcome (accepted, eventually
     roadblocked, etc.). This gives the user a sense of where the codebase's
     true complexity lives.
5. **Discuss findings**: Answer any user questions about the codebase or findings
6. **Reorganize for next task**: Ask the user what they plan to do next with
   this understanding. Reorganize your notes to be actionable for their specific
   next task. Examples:
   - If they plan to fix bugs: organize bugs by file so each file's issues are
     visible at a glance when working on it
   - If they plan to refactor: organize by component/subsystem
   - If they plan to extend: highlight extension points and conventions
   Add documentation maintenance instructions to `MEMORY.md` so future sessions
   know how to keep docs current as changes are made.
7. **Ask about continuation**: After discussion, ask:
   "Would you like me to do another round of N passes? This can help if our
   discussion resolved roadblocked questions or if you'd like me to focus on
   specific areas."

If the user says yes, reset the pass counter and repeat the entire process
(including fresh adversarial rounds), building on all existing notes and
incorporating answers to previously-roadblocked questions.

## Guidelines

- **DO NOT TAKE SHORTCUTS**. Read files thoroughly. Use parallel agents for
  speed, not to skip content.
- **Every pass is a full pass**. Each pass should touch every file in the
  codebase, but allocate time proportionally to remaining uncertainty. Simple,
  well-understood files can be scanned quickly; complex algorithmic files and
  areas rated `surface`/`moderate` in the comprehension map deserve careful
  re-reading. Do not reduce passes to "just answer open questions."
- **Understanding first, issues second**. Your primary job is to deeply learn
  the codebase. Bug-finding is valuable but secondary.
- **Be specific**: Always include exact `file_path:line_number` references.
- **Prioritize findings**: Critical bugs first, cosmetic issues last.
- **Distinguish fact from speculation**: Only mark something as confirmed if
  you've verified it. Use "potential issue" for unverified concerns.
- **Work autonomously**: Do all passes without interrupting the user. Only check
  in when termination criteria are met.
- **Use parallel agents**: Launch multiple Explore/research agents simultaneously
  to inspect different files or investigate different questions. Launch the
  adversarial agent in background at the end of each pass so it works while you
  start the next pass.
- **Write for your future self**: Every note should be clear enough that a fresh
  session with no prior context can pick up exactly where you left off.
- **Manage context proactively**: Compact session logs regularly (see Context
  Window Management). Move discoveries from session logs into persistent files
  immediately. Do not wait for context pressure to force compaction.
