---
name: retro
description: Post-session retrospective — harvest lessons from debugging struggles, extract principles, harden through adversarial critique, distribute to all relevant files
user_invocable: true
---

# /retro — Session Retrospective

Run this after any challenging session: extended debugging, multiple failed
attempts, architectural struggles, anything where we learned the hard way.
Uses the full 1M context window to extract maximum value before it's lost.

## Arguments

Optional: `$ARGUMENTS` provides focus context (e.g., "/retro focus on the
memory management issues" or "/retro the checkpoint loading bugs").

## Process

### Phase 1: HARVEST (Incident Log)

Read through the FULL conversation context. Identify every:
- Bug, mistake, wrong turn, false assumption
- Wasted time (fix declared "done" that wasn't)
- Hard-won insight that wasn't obvious at the start
- Moment where a different approach would have saved time

Write a detailed **incident log** in chronological order: what happened,
what was tried, what failed, what finally worked, how long each round took.
This is the ground truth. Everything else is checked against it.

Save to: `.project-context/knowledge/retro_<date>_incidents.md`

### Phase 2: DOCUMENT (Developer Notes)

Write structured notes from the incident log:
- Each bug: symptoms, root cause, fix, architectural lesson
- Group by category (memory, algorithms, code paths, persistence, process)
- Include a summary table for quick reference

Save to: `.project-context/knowledge/retro_<date>_bugs.md`

### Phase 3: EXTRACT PRINCIPLES

From the documented bugs, formulate operational rules:
- Format: short name, imperative rule, trigger condition, what it prevents
- Each principle MUST reference the concrete incident that motivated it
- "Check X before doing Y" not "be more careful"
- Consider WHERE each principle needs to live to fire at the right moment

Save to: `.project-context/knowledge/retro_<date>_principles.md`

### Phase 4: ADVERSARIAL REFINEMENT LOOP

This is the core. Launch TWO persistent critics in parallel:

**Claude critic** (subagent, claude-opus-4-6):
```
You are a ruthless adversarial critic. You have the FULL incident log
(provided below) and the proposed principles. Your job:

1. Cross-reference every incident against the principles. Is each incident
   covered? Would each principle ACTUALLY have caught its target incident?
   Are any incidents quietly ignored or downplayed?

2. Find at least 10 specific ways the principles are insufficient. For each,
   show a concrete failure scenario where following the principle still
   leads to a bug.

3. Evaluate: will Claude ACTUALLY follow this? Consider context window
   mechanics, file placement, when instructions get read, what gets
   forgotten. A principle in a file Claude doesn't read during the
   relevant task is worthless.

4. Identify meta-problems with the debugging process itself.

Standard: if the exact same situation arose tomorrow, would these principles
cause Claude to handle it DEFINITELY differently, not just PROBABLY?

Do not go easy. Do not sign off until the principles are bulletproof.
```

**Codex critic** (dispatch via scripts/dispatch.sh):
Same instructions, different model. Write critique to a file.

**The loop:**
a) Both critics read principles + full incident log. Cross-reference.
b) Incorporate feedback, rewrite principles.
c) Both critics re-read revision against incident log. Are fixes real
   or cosmetic? Did Claude sneak in softer language?
d) Repeat until BOTH critics explicitly confirm satisfaction — meaning
   they cannot find meaningful remaining weaknesses.
   Not "good enough." Not "nice improvements." Affirmative confirmation
   that each principle is clear, actionable, correctly placed, and
   likely to actually change behavior.

If a critic is not satisfied after 3 rounds, escalate to the user:
"The critics aren't satisfied yet. Here's what's still contentious: [issues].
Want me to keep iterating or accept the current version?"

### Phase 5: DISTRIBUTE

Add battle-tested principles to ALL relevant locations:

- **Project knowledge files**: project-specific lessons
- **Global `~/.claude/knowledge/lessons.md`**: cross-project patterns
- **Global `~/.claude/CLAUDE.md`**: permanent operating rules (if universal)
- **`AGENTS.md`**: so Codex inherits relevant lessons

**Placement matters.** For each principle, think about WHERE it needs to
live to trigger at the right moment:
- Debugging principles go near the bug-fixing/anti-flailing section
- Spec-writing principles go near the spec-writing instructions
- Memory principles go near the OOM prevention section
- Don't just append to the bottom — place where it will be READ when it MATTERS

Append, don't replace. Don't duplicate what's already there.

### Phase 6: SUMMARIZE

Give the user a brief readout:
- Key lessons (top 3-5)
- Principles added and where they were placed
- How many adversarial rounds it took
- What will be different next time
- Any unresolved critiques the user should know about

## Notes

- Use the full 1M context window — this skill exists precisely because
  context is about to be lost
- The adversarial loop is the most important part. Without it, the
  principles are just "things Claude wrote to feel productive"
- The incident log is the bullshit detector. Critics must have it.
- This skill should take 10-20 minutes to run fully. Don't rush it.
- If the session was short or the lessons are minor, say so and skip
  the adversarial loop. Not every session needs a full retro.
