#!/usr/bin/env bash
# new-project.sh — Full project setup: skeleton, git, GitHub, Clodex, tmux
# Usage: new-project.sh <package-name> "<description>" [public|private] [mit|gpl3]
set -euo pipefail

NAME="${1:?Usage: new-project.sh <package-name> \"<description>\" [public|private] [mit|gpl3]}"
DESC="${2:?Provide a description as second argument}"
VISIBILITY="${3:-private}"
LICENSE="${4:-mit}"

PROJECT_DIR="$HOME/projects/$NAME"
SKELETON="$HOME/drop-in/project-skeleton"

if [ ! -d "$SKELETON" ]; then
  echo "Error: Skeleton not found at $SKELETON"
  exit 1
fi

if [ -d "$PROJECT_DIR" ]; then
  echo "Error: $PROJECT_DIR already exists"
  exit 1
fi

# 1. Create project from skeleton
mkdir -p "$PROJECT_DIR"
cp -r "$SKELETON"/. "$PROJECT_DIR"/
cd "$PROJECT_DIR"

# 2. Replace placeholders
if [[ "$LICENSE" == "gpl3" ]]; then
  LICENSE_SPDX="GPL-3.0-only"
else
  LICENSE_SPDX="MIT"
fi

find . -type f -not -path './.git/*' | while read -r f; do
  sed -i "s/{{PACKAGE_NAME}}/$NAME/g" "$f" 2>/dev/null || true
  sed -i "s/{{DESCRIPTION}}/$DESC/g" "$f" 2>/dev/null || true
  sed -i "s/{{LICENSE}}/$LICENSE_SPDX/g" "$f" 2>/dev/null || true
done
echo "✓ Skeleton copied and placeholders filled"

# 3. Create package directory
mkdir -p "src/$NAME"
cat > "src/$NAME/__init__.py" << EOF
"""$DESC"""

__version__ = "0.1.0"
EOF

mkdir -p tests
cat > tests/__init__.py << EOF
EOF

# 4. Make scripts executable
chmod +x scripts/*.sh

# 5. Git init + initial commit
git init
git add .
git commit -m "Initial commit"
echo "✓ Git initialized"

# 6. GitHub repo
gh repo create "$NAME" --"$VISIBILITY" --source=. --push
echo "✓ GitHub repo created ($VISIBILITY)"

# 7. Personal git exclude
mkdir -p .git/info
cat > .git/info/exclude << 'EX'
.vscode/
.idea/
*.swp
*~
scratch.md
notes.md
.DS_Store
EX

# 8. Install Clodex templates (CLAUDE.md, AGENTS.md, .project-context/)
~/drop-in/setup-architect-worker.sh --project

# 9. Commit Clodex infrastructure
git add .
git commit -m "Add project infrastructure"
git push
echo "✓ Infrastructure committed"

# 10. Launch tmux + Claude Code
if tmux has-session -t "$NAME" 2>/dev/null; then
  echo "tmux session '$NAME' exists — attaching"
  tmux attach -t "$NAME"
else
  tmux new-session -d -s "$NAME" -c "$PROJECT_DIR"
  tmux send-keys -t "$NAME" "claude --dangerously-skip-permissions --effort max" Enter
  echo "✓ tmux session '$NAME' ready"
  echo ""
  echo "Attach: tmux attach -t $NAME"
fi
