#!/usr/bin/env bash
# send-image.sh — Send an image to your phone via Pushover
# Usage: send-image.sh <image-path> [caption]
set -euo pipefail
IMAGE="${1:?Usage: send-image.sh <image-path> [caption]}"
CAPTION="${2:-Image: $(basename "$IMAGE")}"

if [ -z "${PUSHOVER_TOKEN:-}" ] || [ -z "${PUSHOVER_USER:-}" ]; then
  echo "Error: PUSHOVER_TOKEN and PUSHOVER_USER must be set" >&2
  exit 1
fi

curl -s \
  -F "token=$PUSHOVER_TOKEN" \
  -F "user=$PUSHOVER_USER" \
  -F "title=$CAPTION" \
  -F "message=$CAPTION" \
  -F "attachment=@$IMAGE" \
  https://api.pushover.net/1/messages.json > /dev/null 2>&1

echo "📸 Sent $(basename "$IMAGE") to phone"
