# Global Lessons Learned

Append here after every correction or discovered mistake. Format:
`- [DATE] [PROJECT] LESSON: <what happened> → RULE: <what to do instead>`

<!-- This file is read at session start. Keep it actionable and concise. -->

## 2026-03-18: Billion-Node Scaling Session (dagua)

17 bugs found over ~8 hours. Core failure mode: serial hypothesis testing
(find one bug, declare fixed, wait 30-60 min for next failure). Distilled
rules from adversarial critique by Claude + Codex agents:

### Memory at Scale
- Budget PEAK memory (3-4x base tensor for autograd/sort/temps), not target alloc
- After freeing >1GB: gc.collect() + malloc_trim(0) + torch.cuda.empty_cache() + VERIFY RSS dropped
- `del x` only decrements refcount. Null ALL references (graph objects, closures, module attrs)
- Gate on topology sketch (N, E, depth, max_degree, E/N), not just node count

### Algorithm Selection
- Document cost model (passes x complexity x memory), not just Big-O
- O(waves*E) GPU scan vs O(N+E) CPU CSR: measure, don't assume GPU is faster
- Counting sort for bounded integer keys. Comparison sort is 30x slower at 1B+

### Debugging Discipline
- NEVER fix the first bug found and declare victory. Trace the FULL execution
  path, enumerate ALL O(N+) operations with byte estimates, fix everything at once
- Every fix needs 3 gates: (1) no crash, (2) correct output, (3) resources within 1.5x baseline
- Every long-run bug must create a reusable guardrail (assertion/test), not just a patch
- Run threshold ladder (100K, 1M, 10M) not single smoke test. Test below AND above mode switches

### Checkpoint/Persistence
- Fingerprint schema version + data shape, not source code hashes
- Build and restore paths must be provably symmetric -- diff them line by line
- Checkpoint schema is code (enforced manifest), not documentation (comments that rot)

## 2026-03-20: Competitor Algorithm Pipeline (dagua)

14 incidents over 2 days. Core failure mode: "trust then verify later" --
running pipelines that produce plausible but wrong output, discovering the
problem hours later.

### Reimplementation Fidelity
- Match the INSTALLED CODE, not the paper. Papers describe; code IS. Pin version.
- Match the EXACT RNG source (torch.rand != random.random != np.random.rand with same seed)
- C extensions have internal RNG barriers -- compare OBJECTIVES not positions
- Never claim fidelity without adversarial review. "Looks good" is a draft, not a conclusion

### Benchmark Pipeline
- Verify MECHANISM works before trusting output. Run 2 seeds, check they differ.
- Smoke test with PRODUCTION config (same workers, flags, seeds) before full run
- Show distributions, not just aggregates. Averages across mixed scales are lies.
- Inspect test data properties (weighted? directed? connected?) before comparing

### External Tool Integration
- "Can we run it and get positions back?" is the only question. Subprocess is fine.
- Don't get stuck on Python bindings. subprocess.run() works for any compiled tool.
- Audit ALL adapter configs (device, seed, timeout, iterations) not just ones that error

### Process
- Consolidate scripts before running, not after discovering redundancy
- Understand every CLI flag before running (--no-resume != "skip resume feature")
- Adapter bugs are a CLASS: one audit checklist catches device/seed/timeout/scaling bugs

### Stop Leaving Work on the Table (March 20 second retro)
- If you can NAME an improvement and the path is viable, DO IT. Don't present
  it as a status update. "We could match X" is a task, not information.
- "Physically impossible" (C RNG barrier) is the ONLY valid reason to stop short.
  "It's complex" or "it's 400 lines" is not a reason. Read the code. Translate it.
- Never frame viable work as "future." If it doesn't need a design decision
  from the user, it's current work you haven't started.
- When asked "are you 100% done?" — if you qualify the answer, that means no.
  Do the work your qualification identified, THEN answer.
