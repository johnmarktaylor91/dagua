# Global Patterns & System Improvements

## Reusable Solutions
<!-- Cross-project patterns that work well. Add as discovered. -->

## System Improvement Notes
<!-- Friction points, ideas for improving the architect-worker workflow. -->
<!-- Reference this when the user asks "how can we improve this?" -->
