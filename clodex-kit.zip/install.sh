#!/usr/bin/env bash
# install.sh -- Install the Architect-Worker development system
#
# Usage:
#   ./install.sh --global      # Install ~/.claude/ and ~/.codex/ (do this first)
#   ./install.sh --project     # Install project templates (run from a git repo)
#   ./install.sh --skeleton    # Install ~/drop-in/project-skeleton/ (for new-project.sh)
#   ./install.sh --all         # Everything above
#   ./install.sh --info        # Show what goes where

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

backup_if_exists() {
  if [ -f "$1" ]; then
    cp "$1" "$1.bak"
    echo "  Backed up $1"
  fi
}

safe_copy() {
  # Copy source to dest, skip if dest exists and has content
  local src="$1" dst="$2"
  if [ -f "$dst" ] && [ -s "$dst" ]; then
    echo "  $dst exists with content -- keeping"
  else
    cp "$src" "$dst"
    echo "  + $dst"
  fi
}

install_global() {
  echo "=== Installing global configs ==="
  echo ""

  # Create directories
  for dir in ~/.claude ~/.claude/knowledge ~/.claude/scripts ~/.claude/skills \
             ~/.codex; do
    mkdir -p "$dir"
  done

  # Claude Code global config
  echo "-- ~/.claude/ --"
  backup_if_exists "$HOME/.claude/CLAUDE.md"
  cp "$SCRIPT_DIR/global/claude/CLAUDE.md" ~/.claude/CLAUDE.md
  echo "  + ~/.claude/CLAUDE.md"

  backup_if_exists "$HOME/.claude/settings.json"
  cp "$SCRIPT_DIR/global/claude/settings.json" ~/.claude/settings.json
  echo "  + ~/.claude/settings.json"

  if [ -f "$SCRIPT_DIR/global/claude/keybindings.json" ]; then
    safe_copy "$SCRIPT_DIR/global/claude/keybindings.json" "$HOME/.claude/keybindings.json"
  fi

  # Knowledge seeds
  echo ""
  echo "-- Knowledge --"
  for f in lessons.md patterns.md; do
    safe_copy "$SCRIPT_DIR/global/claude/knowledge/$f" "$HOME/.claude/knowledge/$f"
  done

  # Scripts
  echo ""
  echo "-- Scripts --"
  for f in "$SCRIPT_DIR"/global/claude/scripts/*.sh; do
    fname="$(basename "$f")"
    cp "$f" "$HOME/.claude/scripts/$fname"
    chmod +x "$HOME/.claude/scripts/$fname"
    echo "  + ~/.claude/scripts/$fname"
  done

  # Skills (multi-agent pipelines)
  echo ""
  echo "-- Skills --"
  for skill_dir in "$SCRIPT_DIR"/global/claude/skills/*/; do
    skill="$(basename "$skill_dir")"
    mkdir -p "$HOME/.claude/skills/$skill"
    cp "$skill_dir/SKILL.md" "$HOME/.claude/skills/$skill/SKILL.md"
    echo "  + ~/.claude/skills/$skill/SKILL.md"
  done

  # Codex global config
  echo ""
  echo "-- ~/.codex/ --"
  backup_if_exists "$HOME/.codex/AGENTS.md"
  cp "$SCRIPT_DIR/global/codex/AGENTS.md" ~/.codex/AGENTS.md
  echo "  + ~/.codex/AGENTS.md"

  if [ -f "$SCRIPT_DIR/global/codex/config.toml" ]; then
    backup_if_exists "$HOME/.codex/config.toml"
    cp "$SCRIPT_DIR/global/codex/config.toml" ~/.codex/config.toml
    echo "  + ~/.codex/config.toml"
  fi

  echo ""
  echo "=== Global install complete ==="
  echo ""
  echo "Next steps:"
  echo "  1. Edit ~/.claude/CLAUDE.md to customize for your workflow"
  echo "  2. Review ~/.claude/settings.json permissions"
  echo "  3. Run: ./install.sh --skeleton  (for new-project.sh support)"
  echo "  4. Run: ./install.sh --project   (in any git repo to add project infra)"
}

install_project() {
  echo "=== Installing project templates ==="
  echo ""

  if [ ! -d .git ]; then
    echo "Error: Not in a git repository. Run this from your project root."
    exit 1
  fi

  mkdir -p .project-context/{tasks,knowledge/research} scripts .claude/commands

  # Root-level configs
  for f in CLAUDE.md AGENTS.md; do
    if [ -f "$f" ]; then
      echo "  $f exists -- skipping (edit manually)"
    else
      cp "$SCRIPT_DIR/project-template/$f" "./$f"
      echo "  + $f  (FILL IN the <!-- --> placeholders!)"
    fi
  done

  # .project-context/
  echo ""
  echo "-- .project-context/ --"
  for f in architecture.md conventions.md; do
    safe_copy "$SCRIPT_DIR/project-template/.project-context/$f" ".project-context/$f"
  done
  for f in gotchas.md decisions.md; do
    safe_copy "$SCRIPT_DIR/project-template/.project-context/knowledge/$f" ".project-context/knowledge/$f"
  done
  safe_copy "$SCRIPT_DIR/project-template/.project-context/todos.md" ".project-context/todos.md"

  # Scripts
  echo ""
  echo "-- scripts/ --"
  cp "$SCRIPT_DIR/project-template/scripts/"*.sh ./scripts/
  chmod +x scripts/*.sh
  for f in scripts/*.sh; do echo "  + $f"; done

  # .claude/ commands
  echo ""
  echo "-- .claude/commands/ --"
  for f in review-codebase.md iterate-until-green.md goodnight.md; do
    cp "$SCRIPT_DIR/project-template/.claude/commands/$f" ".claude/commands/$f"
    echo "  + .claude/commands/$f"
  done

  if [ ! -f .claude/settings.json ]; then
    cp "$SCRIPT_DIR/project-template/.claude/settings.json" .claude/settings.json
    echo "  + .claude/settings.json"
  fi

  # .gitignore additions
  if ! grep -q ".project-context/tasks/" .gitignore 2>/dev/null; then
    echo "" >> .gitignore
    cat "$SCRIPT_DIR/project-template/gitignore-additions.txt" >> .gitignore
    echo "  + .gitignore updated"
  fi

  # Personal git exclude
  mkdir -p .git/info 2>/dev/null || true
  if [ -d .git/info ] && [ ! -s .git/info/exclude ]; then
    cp "$SCRIPT_DIR/project-template/git-exclude-template.txt" .git/info/exclude
    echo "  + .git/info/exclude"
  fi

  echo ""
  echo "=== Project install complete ==="
  echo ""
  echo "IMPORTANT: Fill in <!-- --> placeholders in CLAUDE.md and AGENTS.md!"
  echo "These tell Claude and Codex about YOUR specific project."
}

install_skeleton() {
  echo "=== Installing project skeleton ==="
  echo ""

  SKEL_DIR="$HOME/drop-in/project-skeleton"
  mkdir -p "$SKEL_DIR"

  cp -r "$SCRIPT_DIR/project-skeleton"/. "$SKEL_DIR"/
  chmod +x "$SKEL_DIR/scripts/"*.sh 2>/dev/null || true

  echo "  + $SKEL_DIR/"
  echo ""
  echo "Now you can create new projects with:"
  echo "  ~/.claude/scripts/new-project.sh <name> \"<description>\" [public|private] [mit|gpl3]"
}

show_info() {
  cat <<'INFO'
=== Architect-Worker System: What Goes Where ===

GLOBAL (your developer identity -- one-time setup)
  ~/.claude/CLAUDE.md              Architect persona & workflow rules
  ~/.claude/settings.json          Tool permissions, hooks, attribution=off
  ~/.claude/keybindings.json       Keybindings (Alt+Enter for newline)
  ~/.claude/knowledge/lessons.md   Cross-project lessons (grows over time)
  ~/.claude/knowledge/patterns.md  Reusable solutions
  ~/.claude/scripts/new-project.sh Bootstrap new projects
  ~/.claude/scripts/send-image.sh  Send images to phone (Pushover)
  ~/.claude/skills/build/          /build -- multi-agent build pipeline
  ~/.claude/skills/improve/        /improve -- codebase improvement pipeline
  ~/.claude/skills/deepdive/       /deepdive -- multi-pass codebase inspection
  ~/.claude/skills/retro/          /retro -- post-session retrospective
  ~/.claude/skills/test-status/    /test-status -- background test monitor
  ~/.codex/AGENTS.md               Global worker behavior rules
  ~/.codex/config.toml             Model config

PROJECT (per-repo, git-tracked)
  CLAUDE.md                        Project architecture briefing
  AGENTS.md                        Codex implementation guide
  .project-context/architecture.md Module map, data flow, dependencies
  .project-context/conventions.md  Naming, patterns, style rules
  .project-context/todos.md        Living task tracker
  .project-context/knowledge/      Gotchas, decisions, research
  .project-context/tasks/          Ephemeral task artifacts (gitignored)
  .claude/settings.json            Project permissions
  .claude/commands/                 Custom slash commands
  scripts/dispatch.sh              Background task runner
  scripts/check-tasks.sh           Task status checker
  scripts/clean-tasks.sh           Clean old task artifacts

SKELETON (for new projects)
  ~/drop-in/project-skeleton/      Template: .gitignore, pyproject.toml,
                                   CI workflows, scripts, LICENSE

TOOLS NEEDED
  claude                           Claude Code CLI (npm install -g @anthropic-ai/claude-code)
  codex                            OpenAI Codex CLI (npm install -g @openai/codex)
  gh                               GitHub CLI
  ruff                             Python linter
  mypy                             Type checker
  uv                               Fast Python package manager (optional)
INFO
}

case "${1:---all}" in
  --global)   install_global ;;
  --project)  install_project ;;
  --skeleton) install_skeleton ;;
  --all)      install_global; echo ""; install_skeleton ;;
  --info)     show_info ;;
  *)
    echo "Usage: $0 [--global|--project|--skeleton|--all|--info]"
    echo ""
    echo "  --global    Install ~/.claude/ and ~/.codex/ (do this first)"
    echo "  --project   Install project templates (run from a git repo)"
    echo "  --skeleton  Install ~/drop-in/project-skeleton/"
    echo "  --all       global + skeleton (default)"
    echo "  --info      Show what goes where"
    exit 1 ;;
esac
