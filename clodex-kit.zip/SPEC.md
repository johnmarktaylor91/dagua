# Architect-Worker Development System v2

A two-tier agent workflow: Claude Code (architect) + Codex (worker).
Zero-wait, fully autonomous, self-improving software development.

Updated March 13, 2026 — 1M context GA, comprehensive knowledge management,
autonomous iteration, PR lifecycle, and accumulated community wisdom.

---

## 1. Architecture

```
YOU ──────► CLAUDE CODE (architect, 1M ctx, Opus 4.6)
              │  • Plans, reviews, coordinates
              │  • Surfaces decisions and tradeoffs
              │  • Maintains knowledge bank silently
              │  • Creates Codex skills for recurring patterns
              │  • Handles PR lifecycle via gh CLI
              │  • Always available — never blocked on Codex
              │
              ├──► CODEX (worker, gpt-5.3-codex, fresh ctx per task)
              │      • Writes code, runs tests, iterates until green
              │      • Reads AGENTS.md + project context
              │      • One sweep, minimal commits
              │      • Reports: changes, assumptions, controversies
              │
              └──► ntfy.sh ──► YOUR PHONE
                     • Failures: always notify
                     • Test/build completion: notify
                     • Routine code writes: silent
```

## 2. Configuration Layers

```
GLOBAL (~/.claude/, ~/.codex/) — your developer identity
│
├── ~/.claude/CLAUDE.md              Architect persona, workflow protocol
├── ~/.claude/settings.json          Permissions, hooks, attribution=off
├── ~/.claude/knowledge/
│   ├── lessons.md                   Cross-project mistake log
│   └── patterns.md                  Reusable solutions, system improvement notes
├── ~/.codex/AGENTS.md               Worker behavior rules
└── ~/.codex/config.toml             Model selection, reasoning effort

PROJECT (in-repo, git-tracked) — codebase-specific
│
├── CLAUDE.md                        Project architecture briefing
├── AGENTS.md                        Implementation guide for Codex
├── .claude/
│   ├── settings.json                Project permissions, attribution=off
│   └── commands/
│       ├── review-codebase.md       /review-codebase — comprehensive review
│       ├── iterate-until-green.md   /iterate-until-green <cmd> — autonomous retry
│       └── goodnight.md             /goodnight — downtime task runner
├── .project-context/
│   ├── architecture.md              Module map, data flow, key abstractions
│   ├── conventions.md               Style, naming, error handling, testing
│   ├── todos.md                     Living task/bug tracker
│   ├── knowledge/
│   │   ├── gotchas.md               Edge cases, traps (READ BEFORE CHANGES)
│   │   ├── decisions.md             Architectural decision log
│   │   └── research/                Saved web research with sources
│   │       └── <topic>.md
│   └── tasks/                       ← GITIGNORED (ephemeral runtime state)
│       ├── <id>.spec.md
│       ├── <id>.status
│       ├── <id>.result
│       ├── <id>.log
│       └── <id>.diff
└── scripts/
    ├── dispatch.sh                  Background task dispatcher + ntfy
    ├── check-tasks.sh               Status checker
    └── clean-tasks.sh               Cleanup (7-day default)
```

**CC sees BOTH global + project CLAUDE.md** — they're concatenated into the
system prompt. Global loads first, project layers on top. They don't conflict:
global = identity, project = codebase specifics.

**Git tracking:** Everything above is tracked EXCEPT `.project-context/tasks/`.
Global configs live in `~/`, not in repos.

## 3. Key Behaviors

### Design Decisions First
CC surfaces tradeoffs before proposing plans. The user makes hard calls;
CC frames them well. >90% confidence on non-critical decisions → just go and
report afterward.

### Anti-Flailing
3 failed attempts at the same approach → STOP, rethink from scratch, propose
a fundamentally different strategy. Never band-aid symptoms.

### Autonomous Iteration
`/iterate-until-green <command>` — runs, fixes, re-runs until passing. No
human input needed between cycles. Makes conservative choices on ambiguity
and notes them. Stops after 5 consecutive same-issue failures.

### Proactive Downtime Use
User says "goodnight" → `/goodnight` runs full Tier 3 test suite, updates
knowledge files, cleans old tasks. Results wait for the user.

### Silent Knowledge Capture
After every task, CC silently updates relevant knowledge files. Gotchas,
lessons, architecture understanding. No announcement, no permission asked.
The knowledge bank grows organically.

### Self-Improvement
After every user correction → append to `lessons.md` (global + project).
At session start → review recent lessons. When asked "how can we improve?" →
draw from accumulated patterns.md notes.

### Testing Tiers
- **Tier 1** (seconds): Unit tests on changed files. Every Codex task.
- **Tier 2** (minutes): Integration tests. Module boundary changes.
- **Tier 3** (minutes-hours): Full suite + lint + mypy. Downtime only.

### PR Lifecycle
Create: `gh pr create --title "..." --body "..."`
After merge: `git checkout main && git pull && git branch -d <branch> && git remote prune origin`
Triggered by "merged" or "clean up" from user.

### Branch Discipline
One feature branch at a time. Don't spawn extras unless asked. Keep git clean.

### Code Quality (Universal)
- Type hints on ALL functions (mypy strict)
- Docstrings on ALL functions (NumPy format)
- ruff check passes
- No AI attribution in commits, PRs, or code

### Codex Commit Discipline
Batch tasks = one sweep, sensible commits. No micro-commit-per-file pattern.

### Long Script Pre-Flight
Scripts >2min estimated: examine for failure points, add checkpoints, estimate
runtime, consider dry-run first.

### Job Management
Always know what's running. Safe to cancel: superseded tasks, redundant lint.
Ask first: tasks that modified files. Never cancel: user-requested tasks.

## 4. Commands

| Command | Purpose |
|---------|---------|
| `/review-codebase` | Comprehensive review: bugs, edge cases, missing types. Updates knowledge. |
| `/iterate-until-green <cmd>` | Run command, fix failures, repeat until passing. Fully autonomous. |
| `/goodnight` | Run full test suite + maintenance during downtime. |

## 5. Portability

Global configs (`~/.claude/`, `~/.codex/`) copy to new machine via scp.
Project configs travel with the repo. Run `./setup-architect-worker.sh --portability`
for step-by-step new-machine instructions.

Required tools: `claude`, `codex`, `gh`, `ruff`, `mypy`, `pytest`

## 6. System Evolution

This system will change. Designed for adaptability:
- Dispatch protocol is simple — easy to swap Codex for future tools
- Knowledge files are plain markdown — portable anywhere
- CC notes friction and improvement ideas in `patterns.md`
- Periodically ask CC: "How can we improve this system?"

---

*v2.0 — March 13, 2026*
