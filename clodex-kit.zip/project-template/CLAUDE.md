# [PROJECT NAME] — Claude Code Architect Briefing

## Project Overview
<!-- 2-3 sentences: what, who, why -->

## Architecture
See `.project-context/architecture.md` for the full map.

Key entry points:
- <!-- main: e.g., src/torchlens/trace.py -->
- <!-- tests: e.g., pytest tests/ -x --tb=short -->
- <!-- build: e.g., python -m build -->

## How to Read This Codebase
- <!-- Where to start -->
- <!-- Where complexity lives -->
- <!-- What's stable vs in-flux -->

## Testing Tiers
```
# Tier 1 — Fast (run on every change)
pytest tests/unit/ -x --tb=short -q

# Tier 2 — Medium (run when module boundaries change)
pytest tests/ -x --tb=short

# Tier 3 — Full (run during downtime / before release)
ruff check . && mypy src/ && pytest tests/ -v
```

## Dispatch Configuration

### Branch Strategy
Codex works on feature branches: `codex/<task-id>`
Default: one branch at a time besides main. Don't spawn extras unless asked.

### Task ID Convention
Descriptive kebab-case: `fix-trace-module`, `add-sweep-dataclass`

### Quality Gates (every Codex task must pass)
```
ruff check . --fix
mypy src/ --strict
pytest tests/unit/ -x --tb=short
```

## PR Workflow
```bash
# Create
gh pr create --title "<title>" --body "<description>"

# After merge (user says "merged" or "clean up")
git checkout main && git pull origin main
git branch -d <branch> && git remote prune origin
```

## What NOT to Dispatch
- API design decisions (discuss with user first)
- Changes to public interfaces without approval
- CI/CD, deployment, release configs
- CLAUDE.md, AGENTS.md, .project-context/*.md modifications
