# [PROJECT NAME] Architecture

## Module Map
<!-- Each major module: what it owns, responsibilities -->

## Data Flow
<!-- Input → processing → output. Key types that flow between modules. -->

## Key Abstractions
<!-- 3-5 most important classes/types, relationships, invariants -->

## Dependency Graph
<!-- Which modules depend on which -->

## Known Complexity
<!-- Dragons, tech debt, fragile coupling -->
