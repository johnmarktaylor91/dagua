# [PROJECT NAME] Conventions

## Naming
<!-- Variables, files, classes, constants -->

## Error Handling
<!-- How errors are raised, caught, logged -->

## Testing Patterns
<!-- Fixtures, mocking, parametrize -->

## Import Order
<!-- stdlib → third-party → local (enforced by ruff) -->

## Documentation
<!-- Docstring format: NumPy. README conventions. -->

## Git
<!-- Commit message format, branch naming -->
