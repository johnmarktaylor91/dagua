# [PROJECT NAME] — Codex Implementation Guide

## Language & Framework
<!-- e.g., Python 3.11+, PyTorch 2.x -->

## Project Structure
```
<!-- Map your directories -->
```

## Quality Gates (must pass before task is complete)
```
ruff check . --fix
mypy src/ --strict
pytest tests/unit/ -x --tb=short
```

## Conventions
See `.project-context/conventions.md` for full details.
- Type hints required on ALL functions
- Docstrings required on ALL functions (NumPy format)
- Top-level comments on .py files where purpose isn't obvious
- No wildcard imports
- Tests mirror source structure

## Running Tests
```
# Fast (every change)
pytest tests/unit/ -x --tb=short -q

# Full (before PR)
pytest tests/ -v
```

## Environment
<!-- virtualenv, env vars, dependencies -->

## Critical Constraints
- <!-- e.g., Do not modify __init__.py exports without instruction -->
- <!-- e.g., Backward compatibility mandatory for public API -->

## Known Gotchas
See `.project-context/knowledge/gotchas.md` — read before making changes.
