# Clodex: Architect-Worker Development System

A two-tier AI agent workflow: **Claude Code** (architect) plans, reviews, and
coordinates while **Codex** (worker) writes code, runs tests, and iterates.
You talk to Claude; Claude dispatches Codex in the background; you never wait.

## Quick Start (5 minutes)

### 1. Install tools

```bash
npm install -g @anthropic-ai/claude-code @openai/codex
brew install gh ruff mypy   # or: pip install ruff mypy
```

### 2. Authenticate

```bash
claude    # follow auth prompts (Anthropic API key)
codex     # follow auth prompts (OpenAI API key)
gh auth login
```

### 3. Run the installer

```bash
unzip clodex-kit.zip
cd clodex-kit
chmod +x install.sh
./install.sh --all    # installs global configs + project skeleton
```

This installs:
- `~/.claude/` -- architect persona, skills, scripts, knowledge bank
- `~/.codex/` -- worker behavior rules
- `~/drop-in/project-skeleton/` -- template for new projects

### 4. Add to an existing project

```bash
cd ~/projects/your-project
/path/to/clodex-kit/install.sh --project
```

Then **fill in the `<!-- -->` placeholders** in `CLAUDE.md` and `AGENTS.md`
with your project's specifics (architecture, testing commands, conventions).

### 5. Start working

```bash
cd ~/projects/your-project
claude --dangerously-skip-permissions --effort max
```

Or create a brand-new project from scratch:

```bash
~/.claude/scripts/new-project.sh myapp "My cool app" private mit
# Creates repo, skeleton, git, GitHub, Clodex infra, tmux session
```

## How It Works

```
YOU --> CLAUDE CODE (architect, 1M context, Opus)
         |  Plans, reviews, coordinates
         |  Surfaces design decisions (pros/cons/recommendation)
         |  Maintains knowledge bank silently
         |
         +---> CODEX (worker, fresh context per task)
         |       Writes code, runs tests, iterates until green
         |       Reads AGENTS.md + project context
         |
         +---> NOTIFICATIONS --> YOUR PHONE
                 Failures: always. Completions: test/build/lint.
```

### The Dispatch Loop

1. You describe what you want
2. Claude reads the code, surfaces design decisions, proposes a plan
3. You approve (or redirect)
4. Claude writes a task spec (`.project-context/tasks/<id>.spec.md`)
5. Claude dispatches Codex: `scripts/dispatch.sh <id> codex exec --full-auto --ephemeral "$(cat spec)"`
6. Claude immediately returns to conversation (never blocks on Codex)
7. When Codex finishes, Claude reviews the diff and reports back

### Key Skills (slash commands)

| Command | What it does |
|---------|-------------|
| `/build` | Multi-agent pipeline: idea -> architecture -> critique -> execute -> QA |
| `/improve` | 4-agent review -> synthesis -> critique -> fix -> QA |
| `/deepdive` | Multi-pass codebase inspection, builds architecture notes |
| `/retro` | Post-session retrospective: harvest lessons, distribute to all files |
| `/review-codebase` | Systematic code review by severity |
| `/iterate-until-green <cmd>` | Run command, fix failures, repeat until passing |
| `/goodnight` | Full test suite + maintenance while you're away |
| `/test-status` | Check on background test runs |

## What's in the Box

```
clodex-kit/
|-- install.sh                     # One-command installer
|-- SPEC.md                        # Full system specification
|-- README.md                      # You are here
|
|-- global/                        # Installed to ~/.claude/ and ~/.codex/
|   |-- claude/
|   |   |-- CLAUDE.md              # Architect persona (28K of workflow rules)
|   |   |-- settings.json          # Tool permissions, hooks
|   |   |-- keybindings.json       # Key bindings
|   |   |-- knowledge/             # Cross-project wisdom (grows over time)
|   |   |   |-- lessons.md
|   |   |   +-- patterns.md
|   |   |-- scripts/
|   |   |   |-- new-project.sh     # Bootstrap new projects
|   |   |   +-- send-image.sh      # Send images to phone (Pushover)
|   |   +-- skills/                # Multi-agent pipelines
|   |       |-- build/SKILL.md
|   |       |-- improve/SKILL.md
|   |       |-- deepdive/SKILL.md
|   |       |-- retro/SKILL.md
|   |       +-- test-status/SKILL.md
|   +-- codex/
|       |-- AGENTS.md              # Worker behavior rules
|       +-- config.toml            # Model config
|
|-- project-template/              # Per-repo infrastructure
|   |-- CLAUDE.md                  # Project briefing template
|   |-- AGENTS.md                  # Codex guide template
|   |-- .project-context/          # Knowledge bank structure
|   |-- .claude/commands/          # Slash commands
|   +-- scripts/                   # dispatch.sh, check-tasks.sh, clean-tasks.sh
|
|-- project-skeleton/              # For brand-new projects
|   |-- pyproject.toml, LICENSE, .gitignore, .pre-commit-config.yaml
|   |-- .github/workflows/        # CI: lint, quality, release
|   +-- scripts/                   # Task management scripts
|
+-- reference/                     # Real-world example (dagua project)
    |-- CLAUDE.md                  # How a mature project briefing looks
    |-- AGENTS.md                  # How a mature worker guide looks
    +-- .project-context/          # Architecture, conventions, decisions
```

## Customization Guide

### Things You SHOULD Customize

1. **`~/.claude/CLAUDE.md`** -- The architect persona. This is the big one.
   - Notification setup (currently Pushover; swap for ntfy, Slack, etc.)
   - `~/projects/` as default project directory
   - OOM thresholds (tuned for 128GB RAM machine)
   - Terminal unicode rules (may not apply to your terminal)

2. **Per-project `CLAUDE.md`** -- Fill in every `<!-- -->` placeholder:
   - Project overview, architecture, key entry points
   - Testing commands (`pytest`, `cargo test`, `npm test`, etc.)
   - Build commands
   - Quality gates

3. **Per-project `AGENTS.md`** -- Tell Codex about YOUR project:
   - Language, framework, project structure
   - Critical constraints, known gotchas
   - Testing and linting commands

4. **`~/.claude/settings.json`** -- Review the permission allowlist.
   Add tools you use frequently so Claude doesn't prompt every time.

### Things You Can Leave As-Is

- Skills (build, improve, deepdive, retro) -- they're project-agnostic
- dispatch.sh, check-tasks.sh -- generic task infrastructure
- Knowledge bank structure -- fills itself over time
- Codex AGENTS.md (global) -- universal worker rules

### Non-Python Projects

The system is language-agnostic at the core. The Python-specific parts:
- `ruff` / `mypy` quality gates in CLAUDE.md -- swap for your linter/type checker
- `pyproject.toml` in project-skeleton -- replace with your build file
- CI workflows -- adapt to your language

The architect-worker protocol, dispatch system, knowledge bank, and skills
all work regardless of language.

## Notifications Setup

The dispatch script sends notifications on task completion/failure.
Default: Pushover (works offline, reliable).

### Option A: Pushover (recommended)

```bash
# Add to ~/.bashrc or ~/.zshrc
export PUSHOVER_TOKEN="your-app-token"
export PUSHOVER_USER="your-user-key"
```

Get tokens at https://pushover.net

### Option B: ntfy (self-hosted)

Edit `scripts/dispatch.sh` -- replace the Pushover curl with:
```bash
curl -s -H "Title: $TASK_ID" -d "$MSG" "https://ntfy.sh/your-topic"
```

### Option C: No notifications

It works fine without them. Claude checks task status via the status files.

## Key Principles

1. **Claude is the architect. Codex is the worker.** Claude never writes
   implementation code. Codex never makes design decisions.

2. **Specs are self-contained.** Codex has no memory of your conversation.
   Every spec includes: file paths, function signatures, test criteria,
   verification commands, relevant code snippets.

3. **Knowledge accumulates silently.** Claude maintains lesson logs, gotcha
   files, and decision records without you asking. Future sessions benefit.

4. **Anti-flailing is built in.** After 3 failed attempts at the same
   approach, Claude must stop, analyze, and propose a different strategy.

5. **Everything is plain markdown.** No vendor lock-in. Portable anywhere.
   The knowledge bank, task specs, and project context are just files.

## FAQ

**Q: Do I need both Claude and Codex?**
A: Claude alone works -- it just won't dispatch background workers. You
can adapt the system to use Claude subagents instead (the skills already
support this via the Agent tool).

**Q: How do I see what Codex is doing?**
A: `scripts/check-tasks.sh` shows all tasks. `scripts/check-tasks.sh <id>`
shows detail with log tail and diff.

**Q: What if Codex messes something up?**
A: Codex works on a feature branch. Claude reviews the diff before anything
is merged. You always have the final say.

**Q: Does this work on Mac/Windows/Linux?**
A: Mac and Linux natively. Windows via WSL.

**Q: How much does this cost?**
A: Claude Code requires an Anthropic API key (or Max plan). Codex requires
an OpenAI API key (or Plus plan). Both have free tiers for light usage.
